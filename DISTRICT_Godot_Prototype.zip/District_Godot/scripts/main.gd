extends Node3D

const CELL := 4.0
const BUILDING_SCRIPT = preload("res://scripts/procedural_building.gd")

var camera: Camera3D
var orbit_root: Node3D
var yaw := 0.65
var pitch := -0.72
var distance := 30.0
var target := Vector3(0, 0, 0)
var dragging := false
var last_mouse := Vector2.ZERO
var touch_points := {}
var last_pinch := 0.0
var selected_color := 0
var building_count := 0
var status_label: Label
var count_label: Label
var city_root: Node3D
var ground: MeshInstance3D
var colors := [
    Color("#e9a6a0"), Color("#f2c879"), Color("#a8c9b5"),
    Color("#9db8df"), Color("#d5b4d8"), Color("#f0dfc2")
]

func _ready() -> void:
    _make_environment()
    _make_world()
    _make_camera()
    _make_ui()
    _seed_city()

func _make_environment() -> void:
    var env := WorldEnvironment.new()
    var e := Environment.new()
    e.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color("#5d9ec4")
    sky_mat.sky_horizon_color = Color("#c5dce0")
    sky_mat.ground_bottom_color = Color("#6b8c78")
    sky_mat.ground_horizon_color = Color("#b8c9ae")
    sky.sky_material = sky_mat
    e.sky = sky
    e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color = Color("#dce7ee")
    e.ambient_light_energy = 0.75
    e.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    e.fog_enabled = true
    e.fog_light_color = Color("#b7d3d9")
    e.fog_density = 0.0018
    env.environment = e
    add_child(env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -32, 0)
    sun.light_energy = 1.35
    sun.shadow_enabled = true
    sun.directional_shadow_max_distance = 70.0
    add_child(sun)

func _make_world() -> void:
    city_root = Node3D.new()
    city_root.name = "City"
    add_child(city_root)

    var water := MeshInstance3D.new()
    var plane := PlaneMesh.new()
    plane.size = Vector2(180, 180)
    water.mesh = plane
    water.position.y = -0.42
    var wm := StandardMaterial3D.new()
    wm.albedo_color = Color("#6db8c5")
    wm.roughness = 0.28
    wm.metallic = 0.08
    wm.transparency = BaseMaterial3D.TRANSPARENCY_DISABLED
    water.material_override = wm
    city_root.add_child(water)

    var island := MeshInstance3D.new()
    var island_mesh := CylinderMesh.new()
    island_mesh.top_radius = 28
    island_mesh.bottom_radius = 29
    island_mesh.height = 0.8
    island.mesh = island_mesh
    island.position.y = -0.05
    var landmat := StandardMaterial3D.new()
    landmat.albedo_color = Color("#a9b98a")
    landmat.roughness = 1.0
    island.material_override = landmat
    city_root.add_child(island)

    var grid := MeshInstance3D.new()
    var gm := PlaneMesh.new()
    gm.size = Vector2(56, 56)
    grid.mesh = gm
    grid.position.y = 0.37
    var gridmat := StandardMaterial3D.new()
    gridmat.albedo_color = Color("#c8c49e")
    gridmat.roughness = 1.0
    grid.material_override = gridmat
    city_root.add_child(grid)

    _make_grid_lines()

func _make_grid_lines() -> void:
    var lines := MeshInstance3D.new()
    var im := ImmediateMesh.new()
    im.surface_begin(Mesh.PRIMITIVE_LINES)
    for i in range(-7, 8):
        var p := float(i) * CELL
        im.surface_add_vertex(Vector3(p, 0.385, -28))
        im.surface_add_vertex(Vector3(p, 0.385, 28))
        im.surface_add_vertex(Vector3(-28, 0.385, p))
        im.surface_add_vertex(Vector3(28, 0.385, p))
    im.surface_end()
    lines.mesh = im
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color("#d7d1b3")
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    lines.material_override = mat
    city_root.add_child(lines)

func _make_camera() -> void:
    orbit_root = Node3D.new()
    orbit_root.position = target
    add_child(orbit_root)
    camera = Camera3D.new()
    camera.current = true
    camera.fov = 48
    orbit_root.add_child(camera)
    _update_camera()

func _update_camera() -> void:
    orbit_root.position = target
    var cp := Vector3(
        distance * cos(pitch) * sin(yaw),
        -distance * sin(pitch),
        distance * cos(pitch) * cos(yaw)
    )
    camera.position = cp
    camera.look_at(target, Vector3.UP)

func _make_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var panel := PanelContainer.new()
    panel.position = Vector2(18, 18)
    panel.custom_minimum_size = Vector2(270, 0)
    layer.add_child(panel)
    var vb := VBoxContainer.new()
    vb.add_theme_constant_override("separation", 7)
    panel.add_child(vb)

    var title := Label.new()
    title.text = "DISTRICT  /  CITY BUILDER"
    title.add_theme_font_size_override("font_size", 19)
    vb.add_child(title)
    var subtitle := Label.new()
    subtitle.text = "Процедурный город • прототип"
    subtitle.add_theme_color_override("font_color", Color("#52656b"))
    vb.add_child(subtitle)
    var sep := HSeparator.new()
    vb.add_child(sep)

    var build_btn := Button.new()
    build_btn.text = "＋  Построить дом"
    build_btn.custom_minimum_size.y = 44
    build_btn.pressed.connect(_place_building_at_center)
    vb.add_child(build_btn)

    var color_row := HBoxContainer.new()
    vb.add_child(color_row)
    for i in range(colors.size()):
        var b := Button.new()
        b.custom_minimum_size = Vector2(34, 34)
        b.text = ""
        var sb := StyleBoxFlat.new()
        sb.bg_color = colors[i]
        sb.corner_radius_top_left = 8
        sb.corner_radius_top_right = 8
        sb.corner_radius_bottom_left = 8
        sb.corner_radius_bottom_right = 8
        b.add_theme_stylebox_override("normal", sb)
        b.pressed.connect(func(): selected_color = i)
        color_row.add_child(b)

    count_label = Label.new()
    count_label.text = "Зданий: 0"
    vb.add_child(count_label)
    status_label = Label.new()
    status_label.text = "Перетаскивай экран для вращения камеры"
    status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    status_label.custom_minimum_size.y = 38
    status_label.add_theme_color_override("font_color", Color("#52656b"))
    vb.add_child(status_label)

    var hint := Label.new()
    hint.text = "Колесо / щипок — масштаб\nКнопка — строительство в центре"
    hint.add_theme_font_size_override("font_size", 12)
    hint.add_theme_color_override("font_color", Color("#65777b"))
    vb.add_child(hint)

func _seed_city() -> void:
    var positions := [
        Vector2i(-2,-1), Vector2i(-1,-1), Vector2i(0,-1), Vector2i(1,-1),
        Vector2i(-2,0), Vector2i(-1,0), Vector2i(0,0), Vector2i(1,0),
        Vector2i(-1,1), Vector2i(0,1), Vector2i(1,1), Vector2i(2,1),
        Vector2i(-2,2), Vector2i(-1,2), Vector2i(0,2)
    ]
    for i in range(positions.size()):
        _create_building(positions[i], i % colors.size(), (i % 3) + 1)

func _place_building_at_center() -> void:
    var cell := Vector2i(round(target.x / CELL), round(target.z / CELL))
    var candidate := cell
    var attempts := 0
    while _cell_occupied(candidate) and attempts < 80:
        attempts += 1
        candidate = cell + Vector2i((attempts % 9) - 4, int(attempts / 9) - 4)
    if attempts >= 80:
        status_label.text = "Рядом нет свободного места — отодвинь камеру"
        return
    _create_building(candidate, selected_color, randi_range(1, 4))
    status_label.text = "Дом построен"

func _cell_occupied(cell: Vector2i) -> bool:
    for child in city_root.get_children():
        if child.has_meta("grid_cell") and child.get_meta("grid_cell") == cell:
            return true
    return false

func _create_building(cell: Vector2i, color_index: int, floors: int) -> void:
    if _cell_occupied(cell):
        return
    var b = BUILDING_SCRIPT.new()
    b.setup(colors[color_index], floors, CELL)
    b.position = Vector3(cell.x * CELL, 0.4, cell.y * CELL)
    b.set_meta("grid_cell", cell)
    city_root.add_child(b)
    building_count += 1
    count_label.text = "Зданий: %d" % building_count

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseButton:
        if event.button_index == MOUSE_BUTTON_LEFT:
            dragging = event.pressed
            last_mouse = event.position
        elif event.button_index == MOUSE_BUTTON_WHEEL_UP and event.pressed:
            distance = max(10.0, distance - 2.0)
            _update_camera()
        elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN and event.pressed:
            distance = min(70.0, distance + 2.0)
            _update_camera()
    elif event is InputEventMouseMotion and dragging:
        var d := event.position - last_mouse
        yaw -= d.x * 0.006
        pitch = clamp(pitch - d.y * 0.004, -1.25, -0.18)
        last_mouse = event.position
        _update_camera()
    elif event is InputEventScreenTouch:
        if event.pressed:
            touch_points[event.index] = event.position
            if touch_points.size() == 2:
                var vals = touch_points.values()
                last_pinch = vals[0].distance_to(vals[1])
        else:
            touch_points.erase(event.index)
            last_pinch = 0.0
    elif event is InputEventScreenDrag:
        if touch_points.has(event.index):
            var old: Vector2 = touch_points[event.index]
            touch_points[event.index] = event.position
            if touch_points.size() == 1:
                var delta := event.position - old
                yaw -= delta.x * 0.006
                pitch = clamp(pitch - delta.y * 0.004, -1.25, -0.18)
                _update_camera()
            elif touch_points.size() == 2:
                var vals = touch_points.values()
                var pinch := vals[0].distance_to(vals[1])
                if last_pinch > 0:
                    distance = clamp(distance - (pinch - last_pinch) * 0.025, 10.0, 70.0)
                    _update_camera()
                last_pinch = pinch
    elif event is InputEventMagnifyGesture:
        distance = clamp(distance / event.factor, 10.0, 70.0)
        _update_camera()
