extends Node3D

var base_color := Color("#e9a6a0")
var floors := 2
var cell_size := 4.0
var rng := RandomNumberGenerator.new()

func setup(color: Color, floor_count: int, size: float) -> void:
    base_color = color
    floors = floor_count
    cell_size = size

func _ready() -> void:
    rng.randomize()
    _build()

func _mat(c: Color, rough := 0.9) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = rough
    return m

func _box(parent: Node3D, size: Vector3, pos: Vector3, material: Material, bevel := false) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = size
    mi.mesh = mesh
    mi.position = pos
    mi.material_override = material
    parent.add_child(mi)
    return mi

func _build() -> void:
    var wall := _mat(base_color)
    var trim := _mat(base_color.darkened(0.18))
    var roof := _mat(base_color.darkened(0.32))
    var glass := _mat(Color("#8fc6d1"), 0.25)
    var dark := _mat(Color("#46545a"))
    var door_mat := _mat(Color("#72564a"))
    var width := cell_size * rng.randf_range(0.72, 0.88)
    var depth := cell_size * rng.randf_range(0.72, 0.88)
    var floor_h := 1.35
    var total_h := floors * floor_h

    # Main sculpted building volume, with a stepped upper facade.
    _box(self, Vector3(width, total_h, depth), Vector3(0, total_h * 0.5, 0), wall)
    _box(self, Vector3(width + 0.16, 0.16, depth + 0.16), Vector3(0, 0.13, 0), trim)
    for f in range(floors):
        var y := 0.45 + f * floor_h
        _box(self, Vector3(width + 0.12, 0.10, depth + 0.12), Vector3(0, y, 0), trim)

        # Front windows: recessed-looking dark frames and blue glass panes.
        var window_y := y + 0.48
        for xside in [-1.0, 1.0]:
            var wx := xside * width * 0.25
            _box(self, Vector3(0.66, 0.78, 0.10), Vector3(wx, window_y, depth * 0.5 + 0.035), dark)
            _box(self, Vector3(0.52, 0.64, 0.045), Vector3(wx, window_y, depth * 0.5 + 0.095), glass)
            _box(self, Vector3(0.58, 0.07, 0.10), Vector3(wx, window_y - 0.43, depth * 0.5 + 0.10), trim)
            _box(self, Vector3(0.07, 0.70, 0.08), Vector3(wx, window_y, depth * 0.5 + 0.12), trim)

        # Side windows.
        for zside in [-1.0, 1.0]:
            var wz := zside * depth * 0.24
            _box(self, Vector3(0.08, 0.65, 0.48), Vector3(width * 0.5 + 0.04, window_y, wz), dark)
            _box(self, Vector3(0.045, 0.52, 0.36), Vector3(width * 0.5 + 0.09, window_y, wz), glass)

        # Small balcony rails on upper floors.
        if f > 0 and rng.randf() > 0.35:
            var balcony_y := y + 0.12
            _box(self, Vector3(0.95, 0.10, 0.42), Vector3(0, balcony_y, depth * 0.5 + 0.22), trim)
            _box(self, Vector3(0.95, 0.28, 0.055), Vector3(0, balcony_y + 0.19, depth * 0.5 + 0.40), _mat(Color("#e8e1d2")))
            for bx in [-0.38, -0.13, 0.13, 0.38]:
                _box(self, Vector3(0.035, 0.28, 0.05), Vector3(bx, balcony_y + 0.19, depth * 0.5 + 0.40), trim)

    # Ground-floor door and lintel.
    _box(self, Vector3(0.48, 0.92, 0.09), Vector3(0, 0.57, depth * 0.5 + 0.08), door_mat)
    _box(self, Vector3(0.64, 0.10, 0.13), Vector3(0, 1.08, depth * 0.5 + 0.08), trim)

    # Roof: pitched roof made from two rotated slabs, plus chimney.
    var roof_y := total_h + 0.28
    var roof_a := _box(self, Vector3(width * 0.58, 0.18, depth + 0.42), Vector3(-width * 0.24, roof_y, 0), roof)
    roof_a.rotation.z = -0.48
    var roof_b := _box(self, Vector3(width * 0.58, 0.18, depth + 0.42), Vector3(width * 0.24, roof_y, 0), roof)
    roof_b.rotation.z = 0.48
    _box(self, Vector3(0.34, 0.9, 0.34), Vector3(width * 0.24, total_h + 0.65, -depth * 0.2), trim)

    # Cornice and decorative front sign/plaster strip.
    _box(self, Vector3(width + 0.24, 0.18, depth + 0.24), Vector3(0, total_h + 0.08, 0), trim)
    _box(self, Vector3(0.95, 0.16, 0.08), Vector3(0, total_h - 0.12, depth * 0.5 + 0.10), _mat(Color("#f4e8d2")))

    # Ground shadow/plinth.
    _box(self, Vector3(width + 0.3, 0.16, depth + 0.3), Vector3(0, 0.08, 0), _mat(Color("#8e9b7d")))
